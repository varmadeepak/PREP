interface ElevatorControlStrategy {
   int determinNextStop(int floor); 
}
