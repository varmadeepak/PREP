public enum ElevatorDirection {
    UP,DOWN,IDLE
}
