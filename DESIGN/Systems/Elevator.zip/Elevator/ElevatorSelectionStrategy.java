
interface ElevatorSelectionStrategy {
    int selectElevator(ExternalRequest externalRequest);
}
