
enum ElevatorStatus {
    IDLE,MOVING,STOPPED
}
