
public abstract class CreditCardPayment {
    public abstract void makeCreditCardPayment(double amount);
}
