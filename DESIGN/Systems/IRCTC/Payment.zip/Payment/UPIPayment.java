
public abstract class UPIPayment {
    public abstract void makeUPIPayment(double amount);
}
