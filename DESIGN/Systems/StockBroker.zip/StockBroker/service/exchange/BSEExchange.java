package service.exchange;

import model.Order;

public class BSEExchange implements StockExchange {

    @Override
    public void executeOrder(Order order) {
        System.out.println("[BSE] Executed Order with id : " + order.getOrderId());
    }
    
}