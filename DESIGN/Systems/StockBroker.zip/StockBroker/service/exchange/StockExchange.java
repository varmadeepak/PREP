package service.exchange;

public interface StockExchange {

}
